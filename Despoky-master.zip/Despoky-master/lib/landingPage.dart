import 'package:flutter/material.dart';


class landingPage extends StatelessWidget {

  const landingPage ({Key? key}) : super (key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }


}