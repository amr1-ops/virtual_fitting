class AppRoutes {
  static const String landingPageRoute = '/';
  static const String loginPageRoute = '/login';
  static const String registerPageRoute = '/register';

  static const String checkoutPageRoute = '/checkout';
  static const String addAddressPageRoute = '/add address';

  static const String bottomNavBarPageRoute = '/bottom navbar';

  static const String profileDetailesPageRoute = '/profile detailes';
  static const String categoryDetailesPageRoute = '/category detailes';
  static const String editProfilePageRoute = '/edit profile';
  static const String deleteProfilePageRoute = '/delete profile';
  static const String productDetailesPageRoute = '/product detailes';






}