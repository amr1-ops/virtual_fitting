class appAssets {
  static const String product_1 = 'assets/products/adults/';
  static const String product_2 = 'assets/images/product_2.png';
  static const String product_3 = 'assets/images/product_3.png';
  static const String product_4 = 'assets/images/product_4.png';
  static const String product_5 = 'assets/images/product_5.png';
  static const String product_6 = 'assets/images/product_6.png';


  static const String homeImage = 'assets/images/homecover.png';

  static const String masterCard = 'assets/images/Mastercard-logo.png';
  static const String delivery_1 = 'assets/images/delivery1.png';
  static const String delivery_2 = 'assets/images/delivery2.png';
  static const String delivery_3 = 'assets/images/delivery3.png';




}